PHP-Simple-CURL-Google-SERP-Proxy-System
========================================

To use this your host is required to allow remote proxy CURL requests. A Proxy list file is generated and saved based on return header status value.

Simple class for sending and retrieving search queries from Google. I plan to add output filtering at some point.

Inspired by an older web based application developed back in 2007. Quickly thrown together in 2011, posted to GitHub in 2012. Still needs to be rewritten.
