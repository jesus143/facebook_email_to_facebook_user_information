<?php
//Silence is Golden
?>